# QG-STEC
Reevaluated QG-STEC data.
